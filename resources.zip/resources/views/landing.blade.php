<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>SMK Negeri 4 Bojonegoro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            min-height: 100vh;
            background: url('{{ asset("img/fotosekolah.png") }}') no-repeat center/cover;
            position: relative;
            color: white;
        }

        body::after {
            content: "";
            position: absolute;
            inset: 0;
            background: rgba(0,0,0,0.65);
        }

        .container {
            position: relative;
            z-index: 2;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* ================= HERO ================= */
        .hero {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 0 20px;
        }

        .hero h1,
        .hero h2,
        .hero p,
        .buttons {
            opacity: 0;
        }

        .hero h1 {
            font-size: clamp(32px, 6vw, 60px);
            font-weight: bold;
            animation: fadeUp 0.8s ease forwards;
        }

        .hero h2 {
            color: #00e0ff;
            margin-bottom: 20px;
            letter-spacing: 2px;
            font-size: clamp(18px, 3vw, 26px);

            animation: fadeUp 0.8s ease forwards;
            animation-delay: 0.4s;
        }

        .hero p {
            max-width: 600px;
            margin-bottom: 30px;
            font-size: clamp(15px, 1.6vw, 20px);
            line-height: 1.7;
            opacity: 0;

            animation: fadeUp 0.8s ease forwards;
            animation-delay: 0.8s;
        }

        .buttons {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            justify-content: center;

            animation: fadeUp 0.8s ease forwards;
            animation-delay: 1.2s;
        }

        .btn-primary {
            background: linear-gradient(90deg, #00c6ff, #0072ff);
            padding: 12px 30px;
            border-radius: 30px;
            text-decoration: none;
            color: white;
            transition: 0.3s;
        }

        .btn-primary:hover {
            transform: scale(1.08);
        }

        .btn-outline {
            border: 2px solid white;
            padding: 12px 30px;
            border-radius: 30px;
            text-decoration: none;
            color: white;
            transition: 0.3s;
        }

        .btn-outline:hover {
            background: white;
            color: black;
        }

        /* ================= ANIMATION ================= */
        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* ================= MOBILE ================= */
        @media (max-width: 768px) {

            .hero {
                min-height: calc(100vh - 60px);
            }

            .buttons {
                flex-direction: column;
                width: 100%;
                gap: 12px;
            }

            .btn-primary,
            .btn-outline {
                width: 100%;
                text-align: center;
            }
        }

        /* ================= DESKTOP (1 BARIS TEKS) ================= */
        @media (min-width: 1024px) {
            .hero p {
                white-space: nowrap;
                max-width: none;
                font-size: 18px;
            }
        }

    </style>
</head>
<body>

<div class="container">

    <!-- HERO -->
    <div class="hero">
        <h1>SMK NEGERI 4</h1>
        <h2>BOJONEGORO</h2>
        <p>
            Website Pengaduan Sarana & Prasarana Sekolah yang cepat, mudah, dan transparan.
        </p>

        <div class="buttons">
            <a href="{{ route('login') }}" class="btn-primary">Login</a>
            <a href="{{ route('register') }}" class="btn-outline">Daftar Sekarang</a>
        </div>
    </div>

</div>

</body>
</html>
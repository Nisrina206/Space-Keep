@extends('layouts.app')

@section('title', 'Splash Screen')

@section('content')
<div class="splash">
    <div class="brand">

        <!-- LOGO -->
        <img src="{{ asset('img/Logo_SMK.png') }}" alt="Logo Sekolah" class="logo">

        <!-- GARIS -->
        <span class="divider">|</span>

        <!-- TEKS -->
        <div class="text-mask"></div>
        <div class="text">
            <span class="smkn">SMKN 4</span>
            <span class="school">BOJONEGORO</span>
        </div>

        <script>
        setTimeout(() => {
            document.querySelector('.splash').classList.add('fade-out');
                setTimeout(() => {
                    window.location.href = "/landing";
                }, 800);
            }, 3500);
        </script>


    </div>
</div>
@endsection
